//
//  FavoritesView.swift
//  PA3
//
//  Created by Alumno on 9/06/25.
//

import SwiftUI

struct FavoritesView: View {
    @StateObject var favoritesViewModel = FavoritesViewModel()

    var body: some View {
        ScrollView {
            VStack (spacing: UIConstants.spacingDefault){
                if(!favoritesViewModel.favorites.isEmpty) {
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
                        ForEach(favoritesViewModel.favorites) { favoriteProduct in
                            FavoriteCardView(product: favoriteProduct, favoritesViewModel: favoritesViewModel)
                        }
                    }
                }
            }
            .padding(UIConstants.paddingDefault)
            .onAppear {
                favoritesViewModel.getAllFavorites()
            }
        }
    }
}
