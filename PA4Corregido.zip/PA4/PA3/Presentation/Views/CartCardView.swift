//
//  CartCardView.swift
//  PA3
//
//  Created by Alumno on 9/06/25.
//

import SwiftUI

struct CartCardView: View {
    let product: Product
    @ObservedObject var productStore: ProductStore
    
    var body: some View {
        VStack (alignment:.leading, spacing: UIConstants.spacingSmall){
            AsyncImage(url: URL(string: product.image)) { image in
                image
                    .resizable()
                    .frame(height: UIConstants.imageSizeSmall)
            } placeholder: {
                ProgressView()
                    .frame(height: UIConstants.imageSizeSmall)
            }
            
            Text(product.title)
                .lineLimit(1)
                .font(.headline)
                .bold()
            
            Text(String(format: "$ %0.2f", product.price * Double(product.quantity)))
                .font(.title3)
                .bold()

            HStack (spacing: UIConstants.spacingDefault){
                Button {
                    productStore.addQuantity(product: product)
                } label: {
                    Image(systemName: "plus.circle.fill")
                        .font(.title2)
                        .foregroundStyle(ColorPalette.primary)
                }

                Text("\(product.quantity)")
                    .font(.title3)
                    .bold()

                Button {
                    productStore.removeQuantity(product: product)
                } label: {
                    Image(systemName: "minus.circle.fill")
                        .font(.title2)
                        .foregroundStyle(ColorPalette.primary)
                }
            }

            Button {
                productStore.removeCart(product: product)
            } label: {
                Text("Remove")
                    .foregroundStyle(Color.white)
                    .padding()
                    .background(Color.red)
                    .bold()
                    .clipShape(RoundedRectangle(cornerRadius: UIConstants.cornerRadiusSmall))
            }
        }
        .padding()
        .clipShape(RoundedRectangle(cornerRadius: UIConstants.cornerRadiusCard))
        .overlay {
            RoundedRectangle(cornerRadius: UIConstants.cornerRadiusCard)
                .stroke(lineWidth: 2)
                .foregroundStyle(ColorPalette.background)
        }
    }
}
