//
//  CartsView.swift
//  PA3
//
//  Created by Alumno on 9/06/25.
//

import SwiftUI

struct CartsView: View {
    @EnvironmentObject var productStore: ProductStore
    
    var body: some View {
        VStack(spacing: UIConstants.spacingDefault) {
            ScrollView {
                switch productStore.state {
                case .idle, .loading:
                    ProgressView("Loading")
                case .success(let products):
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
                        ForEach(products) { product in
                            if(product.inCart) {
                                CartCardView(product: product, productStore: productStore)
                            }
                        }
                    }
                case .failure(let message):
                    VStack {
                        Text("Error: \(message)")
                    }
                }
            }
            .padding(UIConstants.paddingDefault)
            
            Spacer()

            HStack {
                Text("Total: \(String(format: "$ %0.2f", productStore.totalPrice))")
                    .font(.title3)
                    .bold()

                Spacer()

                Button {
                    
                } label: {
                    Text("Shop now")
                        .foregroundStyle(Color.white)
                        .bold()
                        .padding()
                        .background(ColorPalette.primary)
                        .clipShape(RoundedRectangle(cornerRadius: UIConstants.cornerRadiusCard))
                }
            }
            .padding()
            .background(ColorPalette.background)
        }
    }
}
