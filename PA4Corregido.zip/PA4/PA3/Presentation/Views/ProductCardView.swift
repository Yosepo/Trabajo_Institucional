//
//  Untitled.swift
//  EasyShoes
//
//  Created by Alumno on 2/06/25.
//

import SwiftUI

struct ProductCardView: View {
    let product: Product
    @ObservedObject var productStore: ProductStore
    @StateObject var favoritesViewModel: FavoritesViewModel
    
    var body: some View {
        VStack (alignment:.leading, spacing: UIConstants.spacingSmall){
            AsyncImage(url: URL(string: product.image)) { image in
                image
                    .resizable()
                    .frame(height: UIConstants.imageSizeSmall)
            } placeholder: {
                ProgressView()
                    .frame(height: UIConstants.imageSizeSmall)
            }
            
            Text(product.title)
                .lineLimit(1)
                .font(.headline)
                .bold()
            
            HStack {
                Text(String(format: "$ %0.2f", product.price))
                    .font(.title3)
                    .bold()
                
                Spacer()
                
                Button {
                    if favoritesViewModel.checkFavorite(id: product.id) {
                        favoritesViewModel.removeFavorite(id: product.id)
                    } else {
                        favoritesViewModel.addFavorite(favorite: FavoriteProduct(id: product.id, title: product.title, image: product.image, price: product.price))
                    }
                } label: {
                    if favoritesViewModel.checkFavorite(id: product.id) {
                        Image(systemName: "heart.fill")
                            .resizable()
                            .frame(width: UIConstants.iconSize, height: UIConstants.iconSize)
                            .foregroundStyle(ColorPalette.primary)
                    } else {
                        Image(systemName: "heart")
                            .resizable()
                            .frame(width: UIConstants.iconSize, height: UIConstants.iconSize)
                            .foregroundStyle(ColorPalette.primary)
                    }
                }

                Button {
                    if(product.inCart) {
                        productStore.removeCart(product: product)
                    } else {
                        productStore.addCart(product: product)
                    }
                } label: {
                    if(product.inCart) {
                        Image(systemName: "cart.fill")
                            .resizable()
                            .frame(width: UIConstants.iconSize, height: UIConstants.iconSize)
                            .foregroundStyle(ColorPalette.primary)
                    } else {
                        Image(systemName: "cart")
                            .resizable()
                            .frame(width: UIConstants.iconSize, height: UIConstants.iconSize)
                            .foregroundStyle(ColorPalette.primary)
                    }
                }
            }
        }
        .padding()
        .clipShape(RoundedRectangle(cornerRadius: UIConstants.cornerRadiusCard))
        .overlay {
            RoundedRectangle(cornerRadius: UIConstants.cornerRadiusCard)
                .stroke(lineWidth: 2)
                .foregroundStyle(ColorPalette.background)
        }
        .onAppear {
            favoritesViewModel.getAllFavorites()
        }
    }
}
