//
//  ContentView.swift
//  EasyShoes
//
//  Created by Alumno on 26/05/25.
//

import SwiftUI


struct ContentView: View {
    
    @StateObject var productStore = ProductStore()
    
    var body: some View {
        TabView {
            Tab("Home", systemImage: "shoe") {
                HomeView()
                    .onAppear{
                        productStore.getProducts()
                    }
            }
            
            Tab("Favorites", systemImage: "heart") {
                FavoritesView()
            }
            
            Tab("Cart", systemImage: "cart") {
                CartsView()
            }
        }
        .tint(ColorPalette.primary)
        .environmentObject(productStore)
    }
}

#Preview {
    ContentView()
}
