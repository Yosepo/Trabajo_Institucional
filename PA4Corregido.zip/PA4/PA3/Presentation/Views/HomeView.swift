//
//  HomeView.swift
//  EasyShoes
//
//  Created by Alumno on 26/05/25.
//

import SwiftUI

struct HomeView: View {
    
    @EnvironmentObject var productStore: ProductStore
    @State var texto = ""
    
    var body: some View {
        
        TextField("Texto", text: $texto)
            .onSubmit {
                if texto.isEmpty {
                    productStore.productService.url = "https://sugary-wool-penguin.glitch.me/products"
                } else {
                    productStore.productService.url = "https://sugary-wool-penguin.glitch.me/\(texto)"
                }
                productStore.getProducts()
            }
            .textInputAutocapitalization(.never)
        
        ScrollView {
            VStack (spacing: UIConstants.spacingDefault){
           
                switch productStore.state {
                case .idle, .loading:
                    ProgressView("Loading")
                case .success(let products):
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
                        ForEach(products) { product in
                            ProductCardView(product: product, productStore: productStore, favoritesViewModel: FavoritesViewModel())
                        }
                    }
                case .failure(let message):
                    VStack {
                        Text("Error: \(message)")
                    }
                }
                    
                Spacer()
            }
            .padding(UIConstants.paddingDefault)
        }
        
        Spacer()
    }
}

#Preview {
    HomeView()
        .environmentObject(ProductStore())
}
