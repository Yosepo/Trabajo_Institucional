//
//  HomeViewModel.swift
//  EasyShoes
//
//  Created by Alumno on 2/06/25.
//

import Foundation

class ProductStore: ObservableObject {
    @Published var state: UIState<[Product]> = .idle
    @Published var productService = ProductService()
    @Published var totalPrice: Double = 0.0
    
    func getProducts() {
        self.state = .loading
        
        productService.getProduct { data, message in
            
            DispatchQueue.main.async {
                if let data = data {
                    self.state = .success(data)
                } else {
                    self.state = .failure(message ?? "Unknown error")
                }
            }
        }
    }
    
    func addCart(product: Product) {
        updateProducts(product: product, inCart: true)
    }
    
    func removeCart(product: Product) {
        updateProducts(product: product, inCart: false)
    }
    
    func updateProducts(product: Product, inCart: Bool? = nil, quantity: Int? = nil) {
        if case .success(var products) = state {
            if let index = products.firstIndex(where: { $0.id == product.id }) {
                if let inCart = inCart {
                    products[index].inCart = inCart
                }
                if let quantity = quantity {
                    products[index].quantity = quantity > 0 ? quantity : 1
                }
                self.state = .success(products)
                getTotalPrice()
            }
        }
    }

    func getTotalPrice() {
        if case .success(let products) = state {
            let productCart = products.filter{ $0.inCart }
            totalPrice = productCart.reduce(0, { result, number in result + number.price * Double(number.quantity) })
        }
    }

    func addQuantity(product: Product) {
        updateProducts(product: product, quantity: product.quantity + 1)
    }

    func removeQuantity(product: Product) {
        updateProducts(product: product, quantity: product.quantity - 1)
    }
}
