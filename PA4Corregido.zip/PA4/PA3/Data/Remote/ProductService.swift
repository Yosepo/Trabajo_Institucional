//
//  ShoeService.swift
//  EasyShoes
//
//  Created by Alumno on 2/06/25.
//

import Foundation

class ProductService {
    
    var url = "https://sugary-wool-penguin.glitch.me/products"
    
    func getProduct(completion: @escaping ([Product]?, String?) -> Void) {
        HttpRequestHelper().GET(url: url) { data, error in
            
            // Validar que no haya error
            guard error == nil else {
                completion(nil, error)
                return
            }
            
            // Validar que hay datos
            guard let data = data else {
                completion(nil, error)
                return
            }
            
            do {
                let products = try JSONDecoder().decode([ProductResponse].self, from: data).map { productResponse in
                    productResponse.toDomain()
                }
                completion(products, nil)
                
            } catch let decodingError {
                completion(nil, String(describing: decodingError))
            }
        }
    }
}
