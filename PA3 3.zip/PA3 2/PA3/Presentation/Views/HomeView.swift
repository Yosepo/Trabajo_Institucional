//
//  HomeView.swift
//  EasyShoes
//
//  Created by Alumno on 26/05/25.
//

import SwiftUI

struct HomeView: View {
    
    @EnvironmentObject var productStore: ProductStore
    
    var body: some View {
        ScrollView {
            VStack (spacing: UIConstants.spacingDefault){
           
                switch productStore.state {
                case .idle, .loading:
                    ProgressView("Loading")
                case .success(let products):
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
                        ForEach(products) { product in
                            ProductCardView(product: product, productStore: productStore)
                        }
                    }
                case .failure(let message):
                    VStack {
                        Text("Error: \(message)")
                    }
                }
                    
                Spacer()
            }
            .padding(UIConstants.paddingDefault)
        }
        
        Spacer()
    }
}

#Preview {
    HomeView()
        .environmentObject(ProductStore())
}
