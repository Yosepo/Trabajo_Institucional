//
//  ContentView.swift
//  EasyShoes
//
//  Created by Alumno on 26/05/25.
//

import SwiftUI


struct ContentView: View {
    
    @StateObject var productStore = ProductStore()
    
    var body: some View {
        TabView {
            Tab("Home", systemImage: "shoe") {
                HomeView()
                    .environmentObject(productStore)
            }
            
            Tab("Favorites", systemImage: "heart") {
                FavoritesView()
                    .environmentObject(productStore)
            }
            
            Tab("Cart", systemImage: "cart") {
                CartsView()
                    .environmentObject(productStore)
            }
        }
        .tint(ColorPalette.primary)
    }
}

#Preview {
    ContentView()
}
