//
//  FavoritesView.swift
//  PA3
//
//  Created by Alumno on 9/06/25.
//

import SwiftUI

struct FavoritesView: View {
    
    @EnvironmentObject var viewModel: HomeViewModel
    
    var body: some View {
        ScrollView {
            VStack (spacing: UIConstants.spacingDefault){
           
                switch viewModel.state {
                case .idle, .loading:
                    ProgressView("Loading")
                case .success(let products):
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
                        ForEach(products) { product in
                            if(product.isFavorite) {
                                FavoriteCardView(product: product, viewModel: viewModel)
                            }
                        }
                    }
                case .failure(let message):
                    VStack {
                        Text("Error: \(message)")
                    }
                }
            }
            .padding(UIConstants.paddingDefault)
        }
    }
}
