//
//  CartCardView.swift
//  PA3
//
//  Created by Alumno on 9/06/25.
//

import SwiftUI

struct CartCardView: View {
    let product: Product
    @ObservedObject var productStore: ProductStore
    
    var body: some View {
        VStack (alignment:.leading, spacing: UIConstants.spacingSmall){
            AsyncImage(url: URL(string: product.image)) { image in
                image
                    .resizable()
                    .frame(height: UIConstants.imageSizeSmall)
            } placeholder: {
                ProgressView()
                    .frame(height: UIConstants.imageSizeSmall)
            }
            
            Text(product.title)
                .lineLimit(1)
                .font(.headline)
                .bold()
            
            Text(String(format: "$ %0.2f", product.price))
                .font(.title3)
                .bold()
            
            Button {
                productStore.removeCart(product: product)
            } label: {
                Text("Remove")
            }
        }
        .padding()
        .clipShape(RoundedRectangle(cornerRadius: UIConstants.cornerRadiusCard))
        .overlay {
            RoundedRectangle(cornerRadius: UIConstants.cornerRadiusCard)
                .stroke(lineWidth: 2)
                .foregroundStyle(ColorPalette.background)
        }
    }
}
