//
//  Color+Extensions.swift
//  EasyShoes
//
//  Created by Alumno on 26/05/25.
//

import SwiftUI

extension Color {
    static let brandPrimary = Color(red: 255/255, green: 107/255, blue: 53/255 )
}
