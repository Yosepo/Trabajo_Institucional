//
//  HomeViewModel.swift
//  EasyShoes
//
//  Created by Alumno on 2/06/25.
//

import Foundation

class ProductStore: ObservableObject {
    @Published var state: UIState<[Product]> = .idle
    private let productService = ProductService()
    
    init(){
        getProducts()
    }
    
    func getProducts() {
        self.state = .loading
        
        productService.getProduct { data, message in
            
            DispatchQueue.main.async {
                if let data = data {
                    self.state = .success(data)
                } else {
                    self.state = .failure(message ?? "Unknown error")
                }
            }
        }
    }
    
    func addFavorite(product: Product) {
        updateProducts(product: product, isFavorite: true)
    }
    
    func removeFavorite(product: Product) {
        updateProducts(product: product, isFavorite: false)
    }
    
    func addCart(product: Product) {
        updateProducts(product: product, inCart: true)
    }
    
    func removeCart(product: Product) {
        updateProducts(product: product, inCart: false)
    }
    
    func updateProducts(product: Product, isFavorite: Bool? = nil, inCart: Bool? = nil) {
        if case .success(var products) = state {
            if let index = products.firstIndex(where: { $0.id == product.id }) {
                if let isFavorite = isFavorite {
                    products[index].isFavorite = isFavorite
                }
                if let inCart = inCart {
                    products[index].inCart = inCart
                }
                self.state = .success(products)
            }
        }
    }
}
