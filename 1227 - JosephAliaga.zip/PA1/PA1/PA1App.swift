//
//  PA1App.swift
//  PA1
//
//  Created by Alumno on 28/04/25.
//

import SwiftUI

@main
struct PA1App: App {
    var body: some Scene {
        WindowGroup {
            Registro()
        }
    }
}
