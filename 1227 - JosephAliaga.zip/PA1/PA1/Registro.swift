import SwiftUI

struct Registro: View {
    @State var nombreCompleto: String = ""
    @State var cargo: String = ""
    @State var empresa: String = ""
    @State var mostrarFoto: Bool = false

    var body: some View {
        Form {
            Section {
                TextField("Nombre", text: $nombreCompleto)
                TextField("Cargo", text: $cargo)
                TextField("Empresa", text: $empresa)
            }

            Section {
                Button(action: {
                    mostrarFoto = true
                }) {
                    Text("Generar fotocheck")
                }
            }
        }
        .navigationTitle(Text("Bienvenido"))
        .sheet(isPresented: $mostrarFoto) {
            fotoCheck(
                nombreCompleto: nombreCompleto,
                cargo: cargo,
                empresa: empresa
            )
        }
    }
}

#Preview {
    Registro()
}
