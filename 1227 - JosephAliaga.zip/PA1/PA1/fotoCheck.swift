import SwiftUI

struct fotoCheck: View {
    var nombreCompleto: String = ""
    var cargo: String = ""
    var empresa: String = ""
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            VStack {
                Text(empresa).bold()
                
                Image(systemName: "person.circle.fill")
                .resizable()
                .frame(width: 50, height: 50)
                .padding()
                
                Text(nombreCompleto)
                Text(cargo)
            }
            .frame(width: 120, height: 180)
            .padding()
            .background(Color(.secondarySystemBackground))
            .cornerRadius(17)
            .shadow(radius: 5)
            .navigationBarItems(trailing: Button(action: {
                dismiss()
            }) {
                Text("Cerrar")
            })
        }
    }
}

#Preview {
    fotoCheck()
}
