//
//  PA3App.swift
//  PA3
//
//  Created by Alumno on 9/06/25.
//

import SwiftUI

@main
struct PA3App: App {
    let persistenceController = PersistenceController.shared
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
