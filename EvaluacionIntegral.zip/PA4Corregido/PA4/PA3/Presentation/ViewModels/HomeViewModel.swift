//
//  HomeViewModel.swift
//  EasyShoes
//
//  Created by Alumno on 2/06/25.
//

import Foundation

class HomeViewModel: ObservableObject {
    @Published var state: UIState<[SuperHero]> = .idle
    @Published var superHeroService = SuperHeroService()
    
    func searchSuperHero(query: String) {
        self.state = .loading
        
        superHeroService.searchSuperHero(query: query) { data, message in
            if let data = data {
                self.state = .success(data)
            } else {
                self.state = .failure(message ?? "Unknown error")
            }
        }
    }
}
