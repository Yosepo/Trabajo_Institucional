//
//  Untitled.swift
//  EasyShoes
//
//  Created by Alumno on 2/06/25.
//

import SwiftUI

struct SuperHeroCardView: View {

    let superHero: SuperHero
    @StateObject var favoritesViewModel = FavoritesViewModel()
    
    var body: some View {
        VStack (alignment:.leading, spacing: 8){
            AsyncImage(url: URL(string: superHero.image.url)) { image in
                switch image {
                case .empty:
                    ProgressView()
                        .frame(width: 120, height: 160)
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                        .frame(width: 120, height: 160)
                case .failure:
                    Color.gray
                        .frame(width: 120, height: 160)

                @unknown default:
                    EmptyView()
                }
            }
            
            Text(superHero.nombre)
                .lineLimit(1)
                .font(.headline)
                .bold()

            HStack {
                ForEach(superHero.biography.aliases, id: \.alias) { alias in
                    Text(alias.alias)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            HStack {
                Button {
                    if favoritesViewModel.checkFavorite(id: superHero.id) {
                        favoritesViewModel.removeFavorite(id: superHero.id)
                    } else {
                        let aliases = superHero.biography.aliases.map { $0.alias }
                        favoritesViewModel.addFavorite(favorite: FavoriteSuperHero(id: superHero.id, nombre: superHero.nombre, alias: aliases, image: superHero.image.url))
                    }
                } label: {
                    if favoritesViewModel.checkFavorite(id: superHero.id) {
                        Image(systemName: "heart.fill")
                            .resizable()
                            .frame(width: 16, height: 16)
                            .foregroundStyle(.red)
                    } else {
                        Image(systemName: "heart")
                            .resizable()
                            .frame(width: 16, height: 16)
                            .foregroundStyle(.red)
                    }
                }
            }
        }
        .padding()
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .overlay {
            RoundedRectangle(cornerRadius: 8)
                .stroke(lineWidth: 2)
                .foregroundStyle(.gray)
        }
        .onAppear {
            favoritesViewModel.checkFavorite(id: superHero.id)
        }
    }
}
