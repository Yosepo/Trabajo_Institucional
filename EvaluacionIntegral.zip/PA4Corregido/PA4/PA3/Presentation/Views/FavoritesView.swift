//
//  FavoritesView.swift
//  PA3
//
//  Created by Alumno on 9/06/25.
//

import SwiftUI

struct FavoritesView: View {
    
    @StateObject var viewModel = FavoritesViewModel()

    var body: some View {
        ScrollView {
            VStack(spacing: 8) {
                if viewModel.favorites.isEmpty {
                    VStack(spacing: 16) {
                        Image(systemName: "heart.slash")
                            .font(.system(size: 60))
                            .foregroundColor(.gray)
                        Text("No tienes favoritos")
                            .font(.title2)
                            .foregroundColor(.secondary)
                        Text("Agrega superhéroes a tus favoritos desde la pestaña Home")
                            .font(.body)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding()
                } else {
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                        ForEach(viewModel.favorites) { favoriteSuperHero in
                            FavoriteCardView(superHero: favoriteSuperHero, viewModel: viewModel)
                        }
                    }
                }
            }
            .padding(UIConstants.paddingDefault)
            .onAppear {
                viewModel.getAllFavorites()
            }
        }
    }
}
