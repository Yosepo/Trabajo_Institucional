//
//  FavoriteCardView.swift
//  PA3
//
//  Created by Alumno on 9/06/25.
//

import SwiftUI

struct FavoriteCardView: View {
    let superHero: FavoriteSuperHero
    @StateObject var viewModel: FavoritesViewModel

    var body: some View {
        VStack (alignment:.leading, spacing: 8){
            AsyncImage(url: URL(string: superHero.image)) { image in
                switch image {
                case .empty:
                    ProgressView()
                        .frame(width: 120, height: 160)
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                        .frame(width: 120, height: 160)
                case .failure:
                    Color.gray
                        .frame(width: 120, height: 160)

                @unknown default:
                    EmptyView()
                }
            }
            
            Text(superHero.nombre)
                .lineLimit(1)
                .font(.headline)
                .bold()
            
            HStack {
                ForEach(superHero.alias, id: \.self) { alias in
                    Text(alias)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Button {
                viewModel.removeFavorite(id: superHero.id)
            } label: {
                HStack {
                    Image(systemName: "heart.slash")
                    Text("Eliminar")
                }
                .foregroundColor(.red)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Color.red.opacity(0.1))
                .cornerRadius(8)
            }
        }
        .padding()
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .overlay {
            RoundedRectangle(cornerRadius: 8)
                .stroke(lineWidth: 2)
                .foregroundStyle(.gray)
        }
    }
}
