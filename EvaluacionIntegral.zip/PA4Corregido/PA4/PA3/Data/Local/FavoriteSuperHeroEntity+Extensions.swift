extension FavoriteSuperHeroEntity {
    
    func fromDomain(favorite: FavoriteSuperHero) {
        self.id = Int16(favorite.id)
        self.nombre = favorite.nombre
        self.alias = favorite.alias.joined(separator: ",")
        self.image = favorite.image
    }
    
    func toDomain() -> FavoriteSuperHero {
        let aliases = (alias ?? "").split(separator: ",").map { String($0) }
        return FavoriteSuperHero(id: Int(id), nombre: nombre ?? "", alias: aliases, image: image ?? "")
    }
}
