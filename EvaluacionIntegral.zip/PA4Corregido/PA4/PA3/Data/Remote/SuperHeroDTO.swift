struct SuperHeroesDTO: Decodable {
    let superHeroes: [SuperHeroDTO]

    enum CodingKeys: String, CodingKey {
        case superHeroes = "results"
    }
}

struct SuperHeroPowerStatsDTO: Decodable {
    let intelligence: Int?
    let strength: Int?
    let speed: Int?
    let durability: Int?
    let power: Int?
    let combat: Int?
    
    enum CodingKeys: String, CodingKey {
        case intelligence
        case strength
        case speed
        case durability
        case power
        case combat
    }

    func toDomain() -> SuperHeroPowerStats {
        SuperHeroPowerStats(intelligence: intelligence ?? 0, strength: strength ?? 0, speed: speed ?? 0, durability: durability ?? 0, power: power ?? 0, combat: combat ?? 0)
    }
}

struct SuperHeroBiographyDTO: Decodable {
    let fullName: String
    let aliases: [SuperHeroAliasDTO]
    let placeOfBirth: String
    let firstAppearance: String
    let alignment: String

    enum CodingKeys: String, CodingKey {
        case fullName = "full-name"
        case aliases
        case placeOfBirth = "place-of-birth"
        case firstAppearance = "first-appearance"
        case alignment
    }

    func toDomain() -> SuperHeroBiography {
        SuperHeroBiography(fullName: fullName, aliases: aliases.map { $0.toDomain() }, placeOfBirth: placeOfBirth, firstAppearance: firstAppearance, alignment: alignment)
    }
}

struct SuperHeroAliasDTO: Decodable {
    let alias: String
    
    enum CodingKeys: String, CodingKey {
        case alias
    }

    func toDomain() -> SuperHeroAlias {
        SuperHeroAlias(alias: alias)
    }
}

struct SuperHeroImageDTO: Decodable {
    let url: String
    
    enum CodingKeys: String, CodingKey {
        case url
    }

    func toDomain() -> SuperHeroImage {
        SuperHeroImage(url: url)
    }
}

struct SuperHeroDTO: Identifiable, Decodable {
    let id: Int
    let nombre: String
    let powerStats: SuperHeroPowerStatsDTO
    let biography: SuperHeroBiographyDTO
    let images: SuperHeroImageDTO

    enum CodingKeys: String, CodingKey {
        case id
        case nombre
        case powerStats
        case biography
        case images
    }

    func toDomain() -> SuperHero {
        SuperHero(id: id, nombre: nombre, powerStats: powerStats.toDomain(), biography: biography.toDomain(), images: images.toDomain())
    }
}

extension SuperHeroesDTO {
    func toDomain() -> [SuperHero] {
        superHeroes.map { $0.toDomain() }
    }
}