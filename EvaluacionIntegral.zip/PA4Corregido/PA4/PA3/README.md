# Aplicación de Superhéroes

Esta es una aplicación iOS desarrollada en SwiftUI que permite buscar superhéroes y gestionar favoritos.

## Funcionalidades

### 🏠 Pantalla Principal (Home)
- **Búsqueda en tiempo real**: Escribe el nombre de un superhéroe y la aplicación buscará automáticamente
- **Visualización en grid**: Los superhéroes se muestran en un grid de 2 columnas
- **Información detallada**: Cada tarjeta muestra:
  - Imagen del superhéroe
  - Nombre
  - Alias/seudónimos
  - Botón de favorito (corazón)

### ❤️ Pantalla de Favoritos
- **Lista de favoritos**: Muestra todos los superhéroes guardados como favoritos
- **Eliminación**: Puedes eliminar superhéroes de tus favoritos
- **Estado vacío**: Muestra un mensaje cuando no hay favoritos

### 💾 Persistencia Local
- **Core Data**: Los favoritos se guardan localmente usando Core Data
- **Persistencia**: Los datos se mantienen entre sesiones de la aplicación

## Arquitectura

La aplicación sigue una arquitectura MVVM (Model-View-ViewModel) con Clean Architecture:

### 📁 Estructura de carpetas:
- **Data/**: Capa de datos
  - **Remote/**: Servicios de API
  - **Local/**: Persistencia con Core Data
- **Domain/**: Modelos de dominio
- **Presentation/**: Vistas y ViewModels

### 🔧 Componentes principales:

1. **SuperHeroService**: Maneja las llamadas a la API de superhéroes
2. **FavoriteSuperHeroDAO**: Gestiona la persistencia de favoritos
3. **HomeViewModel**: Lógica de la pantalla principal
4. **FavoritesViewModel**: Lógica de la pantalla de favoritos

## API Utilizada

La aplicación utiliza la API pública de SuperHero:
- **URL**: `https://www.superheroapi.com/api.php/f274286a22873ec9fc7a5782940f7ca2/search/[nombre]`
- **Método**: GET
- **Respuesta**: JSON con información detallada del superhéroe

## Instalación y Uso

1. Abre el proyecto en Xcode
2. Compila y ejecuta la aplicación
3. En la pestaña "Home", escribe el nombre de un superhéroe
4. Toca el corazón para agregar/eliminar de favoritos
5. Ve a la pestaña "Favorites" para ver tus superhéroes guardados

## Características técnicas

- **SwiftUI**: Interfaz de usuario moderna
- **Core Data**: Persistencia de datos
- **AsyncImage**: Carga asíncrona de imágenes
- **LazyVGrid**: Grid optimizado para rendimiento
- **URLSession**: Llamadas de red
- **MVVM**: Patrón de arquitectura

## Estados de la UI

La aplicación maneja diferentes estados:
- **Idle**: Estado inicial
- **Loading**: Cargando datos
- **Success**: Datos cargados exitosamente
- **Failure**: Error en la carga

## Manejo de errores

- Errores de red
- Errores de decodificación JSON
- Estados vacíos
- Validación de entrada de usuario 