import SwiftUI

struct UIConstants {
    static let spacingSmall: CGFloat = 8
    static let spacingDefault: CGFloat = 18
    static let paddingDefault: CGFloat = 16
}

struct ColorPalette {
    static let primary = Color.blue
} 