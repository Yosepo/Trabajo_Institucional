struct SuperHeroesDTO: Decodable {
    let response: String
    let superHeroes: [SuperHeroDTO]

    enum CodingKeys: String, CodingKey {
        case response
        case superHeroes = "results"
    }
}

struct SuperHeroPowerStatsDTO: Decodable {
    let intelligence: String
    let strength: String
    let speed: String
    let durability: String
    let power: String
    let combat: String
    
    enum CodingKeys: String, CodingKey {
        case intelligence
        case strength
        case speed
        case durability
        case power
        case combat
    }

    // Otro error, hacer que si string == "null" que sea igual a 0, de lo contrario que ese string se vuelva integer
    func toDomain() -> SuperHeroPowerStats {
        SuperHeroPowerStats(intelligence: intelligence, strength: strength, speed: speed, durability: durability, power: power, combat: combat)
    }
}

struct SuperHeroBiographyDTO: Decodable {
    let fullName: String
    let aliases: [String]
    let placeOfBirth: String
    let firstAppearance: String
    let alignment: String

    enum CodingKeys: String, CodingKey {
        case fullName = "full-name"
        case aliases
        case placeOfBirth = "place-of-birth"
        case firstAppearance = "first-appearance"
        case alignment
    }

    func toDomain() -> SuperHeroBiography {
        SuperHeroBiography(fullName: fullName, aliases: aliases, placeOfBirth: placeOfBirth, firstAppearance: firstAppearance, alignment: alignment)
    }
}

struct SuperHeroImageDTO: Decodable {
    let url: String
    
    enum CodingKeys: String, CodingKey {
        case url
    }

    func toDomain() -> SuperHeroImage {
        SuperHeroImage(url: url)
    }
}

struct SuperHeroDTO: Identifiable, Decodable {
    let id: Int
    let nombre: String
    let powerStats: SuperHeroPowerStatsDTO
    let biography: SuperHeroBiographyDTO
    let images: SuperHeroImageDTO

    enum CodingKeys: String, CodingKey {
        case id
        case nombre
        case powerStats
        case biography
        case images
    }

    func toDomain() -> SuperHero {
        SuperHero(id: id, nombre: nombre, powerStats: powerStats.toDomain(), biography: biography.toDomain(), images: images.toDomain())
    }
}

// Posible error al no agregar al dominio el response
extension SuperHeroesDTO {
    func toDomain() -> [SuperHero] {
        superHeroes.map { $0.toDomain() }
    }
}