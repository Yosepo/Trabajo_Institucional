//
//  ShoeService.swift
//  EasyShoes
//
//  Created by Alumno on 2/06/25.
//

import Foundation

class SuperHeroService {
    
    var url = "https://www.superheroapi.com/api.php/f274286a22873ec9fc7a5782940f7ca2/search/"

// Posible error por el arreglo de SuperHero
    func searchSuperHero(query: String, completion: @escaping ([SuperHero]?, String?) -> Void) {
        guard let url = URL(string:  "\(url)\(query)" ) else {
            return
        }
        
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "GET"
        
        let session = URLSession.shared
        
        session.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    completion(nil, error.localizedDescription)
                }
                return
            }
            
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(nil, "No data received")
                }
                return
            }
            
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                DispatchQueue.main.async {
                    completion(nil, "Invalid response")
                }
                return
            }
            // Revisar que funcione bien
            do {
                let superHeroesResponse = try JSONDecoder().decode(SuperHeroesDTO.self, from: data)
                if(superHeroesResponse.response == "success") {
                    let superHeroes = superHeroesResponse.toDomain()
                    completion(superHeroes, nil)
                } else {
                    completion(nil, "Data not found")
                }
            } catch let decodingError {
                completion(nil, String(describing: decodingError))
            }
        }.resume()
    }
}
