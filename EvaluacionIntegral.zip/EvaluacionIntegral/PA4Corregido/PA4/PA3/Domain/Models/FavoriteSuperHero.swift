import Foundation

struct FavoriteSuperHero: Identifiable {
    let id: Int
    let nombre: String
    let alias: [String]
    let image: String
}