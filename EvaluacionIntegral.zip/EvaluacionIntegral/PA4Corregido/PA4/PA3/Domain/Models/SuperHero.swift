import Foundation

struct SuperHero: Identifiable, Equatable {
    let id: Int
    let nombre: String
    let powerStats: SuperHeroPowerStats
    let biography: SuperHeroBiography
    let image: SuperHeroImage
}

struct SuperHeroPowerStats: Equatable {
    let intelligence: Int
    let strength: Int
    let speed: Int
    let durability: Int
    let power: Int
    let combat: Int
}

struct SuperHeroBiography: Equatable {
    let fullName: String
    let aliases: [String]
    let placeOfBirth: String
    let firstAppearance: String
    let alignment: String
}

struct SuperHeroImage: Equatable {
    let url: String
}