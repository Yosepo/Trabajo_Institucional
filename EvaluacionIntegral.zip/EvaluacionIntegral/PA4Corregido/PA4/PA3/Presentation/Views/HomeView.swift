//
//  HomeView.swift
//  EasyShoes
//
//  Created by Alumno on 26/05/25.
//

import SwiftUI

struct HomeView: View {
    
    @StateObject var viewModel = HomeViewModel()
    @State var query = ""
    @State var selectedSuperHero: SuperHero? = nil
    
    var body: some View {
        VStack {
            HStack {
                TextField("Buscar superhéroe...", text: $query)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(8)
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    .padding(.horizontal)
                    .textInputAutocapitalization(.never)
                    .onSubmit {
                        if !query.isEmpty {
                            viewModel.searchSuperHero(query: query)
                        }
                    }
                // Borrar ese boton de abajo
                Button("Buscar") {
                    if !query.isEmpty {
                        viewModel.searchSuperHero(query: query)
                    }
                }
                .disabled(query.isEmpty)
            }
            .padding()
            
            ScrollView {
                VStack(spacing: 18) {
                    switch viewModel.state {
                    case .idle:
                        Text("Escribe el nombre de un superhéroe para buscar")
                            .foregroundColor(.secondary)
                            .padding()
                    case .loading:
                        ProgressView("Cargando...")
                            .padding()
                    case .success(let superheroes): // Comprobar los mensajes de Data not found y ese
                        if superheroes.isEmpty {
                            Text("No se encontraron superhéroes")
                                .foregroundColor(.secondary)
                                .padding()
                        } else {
                            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                                ForEach(superheroes) { superhero in
                                    SuperHeroCardView(superHero: superhero)
                                        .onTapGesture {
                                            selectedSuperhero = superhero
                                        }
                                }
                            }
                        }
                    case .failure(let message):
                        VStack {
                            Image(systemName: "exclamationmark.triangle")
                                .font(.largeTitle)
                                .foregroundColor(.red)
                            Text("Error: \(message)")
                                .foregroundColor(.red)
                        }
                        .padding()
                    }
                }
                .padding()
                .sheet(item: $selectedSuperHero) { superHero in
                    SuperHeroDetailView(superHero: superHero)
                }
            }
        }
    }
}

#Preview {
    HomeView()
}
