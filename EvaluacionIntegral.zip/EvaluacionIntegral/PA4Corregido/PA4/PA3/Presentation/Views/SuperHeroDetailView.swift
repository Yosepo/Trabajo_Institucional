import SwiftUI

struct SuperHeroDetailView: View {

    let superHero: SuperHero
    
    @StateObject var viewModel = SuperHeroDetailViewModel()
    
    var body: some View {
        VStack (alignment:.leading, spacing: 8){
            ZStack (alignment: .topTrailing){
                AsyncImage(url: URL(string: superHero.image.url)) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(height: 240)
                        .frame(maxWidth: .infinity)
                } placeholder: {
                    ProgressView()
                        .frame(height: 240)
                        .frame(maxWidth: .infinity)
                }

                Button {
                    viewModel.toggleFavorite(superHero: superHero)
                } label: {
                    Image(systemName: viewModel.isFavorite ? "heart.fill" : "heart")
                        .resizable()
                        .frame(width: 30, height: 30)
                }

            }

            
            Text(superHero.nombre)
                .font(.largeTitle)
                .bold()
            
            ScrollView(.horizontal) {
                HStack {
                    ForEach(superHero.biography.aliases) { alias in
                        Text(alias)
                            .font(.caption)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.blue.opacity(0.2))
                            .foregroundColor(.blue)
                            .clipShape(Capsule())
                    }
                }
            }
            
            HStack {
                VStack {
                    Text(superHero.biography.fullName)
                    Text(superHero.biography.placeOfBirth)
                    Text(superHero.biography.firstAppearance)
                    Text(superHero.biography.alignment)
                }

                VStack {
                    Text("Inteligencia: \(superHero.powerStats.intelligence)")
                    Text("Fuerza: \(superHero.powerStats.strength)")
                    Text("Velocidad: \(superHero.powerStats.speed)")
                    Text("Durabilidad: \(superHero.powerStats.durability)")
                    Text("Poder: \(superHero.powerStats.power)")
                    Text("Combate: \(superHero.powerStats.combat)")
                }
            }
            
            Spacer()
        }
        .onAppear {
            viewModel.checkFavorite(id: superHero.id)
        }
        .padding()
    }
}