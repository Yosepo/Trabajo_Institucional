//
//  FavoritesViewModel.swift
//  PA3
//
//  Created by Alumno on 23/06/25.
//

import Foundation

class FavoritesViewModel: ObservableObject {
    
    @Published var favorites = [FavoriteSuperHero]()
    private let dao = FavoriteSuperHeroDAO.shared

    func getAllFavorites() {
        favorites = dao.fetchAllFavorites()
    }

    func addFavorite(favorite: FavoriteSuperHero) {
        dao.insertFavorite(favorite: favorite)
        getAllFavorites()
    }

    func removeFavorite(id: Int) {
        dao.deleteFavorite(id: id)
        getAllFavorites()
    }

    func checkFavorite(id: Int) -> Bool {
        return dao.checkFavorite(id: id)
    }
}
