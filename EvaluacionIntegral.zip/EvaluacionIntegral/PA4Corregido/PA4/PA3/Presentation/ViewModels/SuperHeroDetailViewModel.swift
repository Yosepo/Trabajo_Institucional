import Foundation

class SuperHeroDetailViewModel: ObservableObject {

    let dao = FavoriteSuperHeroDAO.shared
    @Published var isFavorite = false
    
    func checkFavorite(id: Int) {
        isFavorite = dao.checkFavorite(id: id)
    }
    
    func toggleFavorite(superHero: SuperHero) {
        isFavorite.toggle()
        
        if (isFavorite) {
            addFavorite(superHero: superHero)
        } else {
            removeFavorite(id: superHero.id)
        }
    }
    
    private func removeFavorite(id: Int) {
        dao.deleteFavorite(id: id)
    }
    
    private func addFavorite(superHero: SuperHero) {
        let aliases = superHero.biography.aliases
        dao.insertFavorite(favorite: FavoriteSuperHero(id: superHero.id, nombre: superHero.nombre, alias: aliases, image: superHero.image.url))
    }
}