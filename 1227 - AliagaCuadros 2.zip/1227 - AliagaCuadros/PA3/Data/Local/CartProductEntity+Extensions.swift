//
//  FavoriteShoeEntity+Extensions.swift
//  EasyShoes
//
//  Created by Alumno on 16/06/25.
//

extension CartProductEntity {
    
    func fromDomain(cart: CartProduct) {
        self.id = Int16(cart.id)
        self.title = cart.title
        self.image = cart.image
        self.price = Double(cart.price)
    }
    
    func toDomain() -> CartProduct {
        CartProduct(id: Int(id), title: title ?? "", image: image ?? "", price: Double(price))
    }
}
