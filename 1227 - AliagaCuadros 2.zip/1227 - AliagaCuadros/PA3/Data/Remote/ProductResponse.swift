//
//  ShoeResponse.swift
//  EasyShoes
//
//  Created by Alumno on 2/06/25.
//

struct ProductResponse: Identifiable, Decodable {
    let id: Int
    let title: String
    let price: Double
    let image: String
    let rates: ProductRateResponse
    
    enum CodingKeys: String, CodingKey {
        case id
        case title
        case price
        case image
        case rates = "rating"
    }
    
}

struct ProductRateResponse: Decodable {
    let rate: Double
    let count: Int
}

extension ProductResponse {
    func toDomain() -> Product {
        Product(id: id, title: title, price: price, image: image)
    }
}
