//
//  FavoritesViewModel.swift
//  PA3
//
//  Created by Alumno on 23/06/25.
//

import Foundation

class FavoritesViewModel: ObservableObject {
    @Published var favorites = [FavoriteProduct]()
    private let dao = FavoriteProductDAO.shared
    
    func getAllFavorites() {
        favorites = dao.fetchAllFavorites()
    }
}
