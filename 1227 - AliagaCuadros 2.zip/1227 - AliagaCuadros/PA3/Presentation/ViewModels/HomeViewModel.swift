//
//  HomeViewModel.swift
//  PA3
//
//  Created by Alumno on 23/06/25.
//

import Foundation

class HomeViewModel: ObservableObject {
    @Published var state: UIState<[Product]> = .idle
    private let productService = ProductService()
    
    init(){
        getProducts()
    }
    
    func getProducts() {
        self.state = .loading
        
        productService.getProducts { data, message in
            
            DispatchQueue.main.async {
                if let data = data {
                    self.state = .success(data)
                } else {
                    self.state = .failure(message ?? "Unknown error")
                }
            }
        }
    }
}
