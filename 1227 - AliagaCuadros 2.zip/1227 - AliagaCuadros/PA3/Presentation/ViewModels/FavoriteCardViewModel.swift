//
//  FavoriteCardViewModel.swift
//  PA3
//
//  Created by Alumno on 23/06/25.
//

import Foundation

class FavoriteCardViewModel: ObservableObject {
    let dao = FavoriteProductDAO.shared
    
    func removeFavorite(id: Int) {
        dao.deleteFavorite(id: id)
    }
    
}
