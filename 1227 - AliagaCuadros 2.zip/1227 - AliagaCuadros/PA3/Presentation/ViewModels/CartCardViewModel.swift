//
//  CartCardViewModel.swift
//  PA3
//
//  Created by Alumno on 23/06/25.
//

import Foundation

class CartCardViewModel: ObservableObject {
    let dao = CartProductDAO.shared
    @Published var carts = [CartProduct]()
    @Published var cart: CartProduct = carts[0]
    
    func getAllCarts() {
        carts = dao.fetchAllCarts()
    }
    
    func removeCart(id: Int) {
        dao.deleteCart(id: id)
    }
    
    func addCount() {
        cart.quantity += 1
    }
}
