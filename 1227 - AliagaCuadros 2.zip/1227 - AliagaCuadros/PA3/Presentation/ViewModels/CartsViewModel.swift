//
//  CartsViewModel.swift
//  PA3
//
//  Created by Alumno on 23/06/25.
//

import Foundation

class CartsViewModel: ObservableObject {
    @Published var carts = [CartProduct]()
    private let dao = CartProductDAO.shared
    
    func getAllCarts() {
        carts = dao.fetchAllCarts()
    }
}
