//
//  ProductCardViewModel.swift
//  PA3
//
//  Created by Alumno on 23/06/25.
//

import Foundation

class ProductCardViewModel: ObservableObject {
    @Published var isFavorite: Bool = false
    @Published var isCart: Bool = false
    private let favoriteDao = FavoriteProductDAO.shared
    private let cartDao = CartProductDAO.shared
    
    func checkFavorite(id: Int) {
        isFavorite = favoriteDao.checkFavorite(id: id)
    }
    
    func toggleFavorite(product: Product) {
        isFavorite.toggle()
        
        if (isFavorite) {
            addFavorite(product: product)
        } else {
            removeFavorite(id: product.id)
        }
    }
    
    private func removeFavorite(id: Int) {
        favoriteDao.deleteFavorite(id: id)
    }
    
    private func addFavorite(product: Product) {
        favoriteDao.insertFavorite(favorite: FavoriteProduct(id: product.id, title: product.title, image: product.image, price: product.price))
    }
    
    
    func checkCart(id: Int) {
        isCart = cartDao.checkCart(id: id)
    }
    
    func toggleCart(product: Product) {
        isCart.toggle()
        
        if (isCart) {
            addCart(product: product)
        } else {
            removeCart(id: product.id)
        }
    }
    
    private func removeCart(id: Int) {
        cartDao.deleteCart(id: id)
    }
    
    private func addCart(product: Product) {
        cartDao.insertCart(cart: CartProduct(id: product.id, title: product.title, image: product.image, price: product.price, quantity: product.quantity))
    }
}
