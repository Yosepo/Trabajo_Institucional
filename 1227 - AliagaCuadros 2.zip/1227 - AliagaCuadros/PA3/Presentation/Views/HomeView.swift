//
//  HomeView.swift
//  EasyShoes
//
//  Created by Alumno on 26/05/25.
//

import SwiftUI

struct HomeView: View {
    
    @StateObject var viewModel = HomeViewModel()
    
    var body: some View {
        ScrollView {
            VStack (spacing: UIConstants.spacingDefault){
                switch viewModel.state {
                case .idle, .loading:
                    ProgressView("Loading")
                case .success(let products):
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
                        ForEach(products) { product in
                            ProductCardView(product: product)
                        }
                    }
                case .failure(let message):
                    VStack {
                        Text("Error: \(message)")
                    }
                }
            }
            .padding(UIConstants.paddingDefault)
        }
        
        Spacer()
    }
}
