//
//  Untitled.swift
//  EasyShoes
//
//  Created by Alumno on 2/06/25.
//

import SwiftUI

struct ProductCardView: View {
    let product: Product
    
    @StateObject var viewModel = ProductCardViewModel()
    
    var body: some View {
        VStack (alignment:.leading, spacing: UIConstants.spacingSmall){
            AsyncImage(url: URL(string: product.image)) { image in
                image
                    .resizable()
                    .scaledToFit()
                    .frame(height: UIConstants.imageSizeSmall)
            } placeholder: {
                ProgressView()
                    .frame(height: UIConstants.imageSizeSmall)
            }
            
            Text(product.title)
                .lineLimit(1)
                .font(.headline)
                .bold()
            
            HStack {
                Text(String(format: "$ %0.2f", product.price))
                    .font(.title3)
                    .bold()
                
                Spacer()
                
                Button {
                    viewModel.toggleFavorite(product: product)
                } label: {
                    Image(systemName: viewModel.isFavorite ? "heart.fill" : "heart")
                        .resizable()
                        .frame(width: UIConstants.iconSize, height: UIConstants.iconSize)
                        .foregroundStyle(ColorPalette.primary)
                }

                Button {
                    viewModel.toggleCart(product: product)
                } label: {
                    Image(systemName: viewModel.isCart ? "cart.fill" : "cart")
                        .resizable()
                        .frame(width: UIConstants.iconSize, height: UIConstants.iconSize)
                        .foregroundStyle(ColorPalette.primary)
                }
            }
        }
        .padding()
        .clipShape(RoundedRectangle(cornerRadius: UIConstants.cornerRadiusCard))
        .overlay {
            RoundedRectangle(cornerRadius: UIConstants.cornerRadiusCard)
                .stroke(lineWidth: 2)
                .foregroundStyle(ColorPalette.background)
        }
        .onAppear {
            viewModel.checkFavorite(id: product.id)
            viewModel.checkCart(id: product.id)
        }
    }
}
