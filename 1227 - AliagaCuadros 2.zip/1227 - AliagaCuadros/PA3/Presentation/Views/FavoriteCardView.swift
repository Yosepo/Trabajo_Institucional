//
//  FavoriteCardView.swift
//  PA3
//
//  Created by Alumno on 9/06/25.
//

import SwiftUI

struct FavoriteCardView: View {
    
    @StateObject var viewModel = FavoriteCardViewModel()
    
    let favorite: FavoriteProduct
    let onDelete: () -> Void
    
    var body: some View {
        HStack {
            AsyncImage(url: URL(string: favorite.image)) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .frame(width: 80, height: 100)
                case .success(let image):
                    image.resizable()
                        .scaledToFit()
                        .frame(width: 80, height: 100)
                case .failure(let error):
                    Text(error.localizedDescription)
                        .frame(width: 80, height: 100)
                @unknown default:
                    EmptyView()
                        .frame(width: 80, height: 100)
                }
            }
            .padding(UIConstants.paddingDefault)
            
            Spacer()
            
            VStack (alignment: .leading) {
                Text(favorite.title)
                    .lineLimit(1)
                    .font(.headline)
                    .bold()
                
                Text(String(format: "$ %0.2f", favorite.price))
                    .font(.title3)
                    .bold()
                
                Button {
                    viewModel.removeFavorite(id: favorite.id)
                    onDelete()
                } label: {
                    Text("Remove")
                }
            }
        }
        .padding()
        .clipShape(RoundedRectangle(cornerRadius: UIConstants.cornerRadiusCard))
        .overlay {
            RoundedRectangle(cornerRadius: UIConstants.cornerRadiusCard)
                .stroke(lineWidth: 2)
                .foregroundStyle(ColorPalette.background)
        }
    }
}
