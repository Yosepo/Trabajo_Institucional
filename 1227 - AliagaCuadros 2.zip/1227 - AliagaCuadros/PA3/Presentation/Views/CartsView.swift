//
//  CartsView.swift
//  PA3
//
//  Created by Alumno on 9/06/25.
//

import SwiftUI

struct CartsView: View {
    
    @StateObject var viewModel = CartsViewModel()
    
    var body: some View {
        VStack {
            if (!viewModel.carts.isEmpty) {
                List {
                    ForEach(viewModel.carts) { cart in
                        CartCardView(cart: cart) {
                            viewModel.getAllCarts()
                        }
                    }
                    .listRowSeparator(.hidden)
                }
                .listStyle(.plain)
            } else {
                Text("No carts")
            }
        }
        .onAppear {
            viewModel.getAllCarts()
        }
        
        Spacer()

        HStack {
            //Text(String(format: "Price total: $ %0.2f", productStore.priceTotal))
         //       .font(.title2)
         //       .bold()

            Spacer()

            Button {

            } label: {
                Text("Shop now")
            }
        }
        .padding(UIConstants.paddingDefault)
    }
}
