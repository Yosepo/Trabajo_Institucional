//
//  CartCardView.swift
//  PA3
//
//  Created by Alumno on 9/06/25.
//

import SwiftUI

struct CartCardView: View {
    
    @StateObject var viewModel = CartCardViewModel()
    
    let cart: CartProduct
    let onDelete: () -> Void
    
    var body: some View {
        VStack (spacing: UIConstants.spacingSmall){
            AsyncImage(url: URL(string: cart.image)) { image in
                image
                    .resizable()
                    .scaledToFit()
                    .frame(height: UIConstants.imageSizeSmall)
            } placeholder: {
                ProgressView()
                    .frame(height: UIConstants.imageSizeSmall)
            }
            
            Text(cart.title)
                .lineLimit(1)
                .font(.headline)
                .bold()
            
            Text(String(format: "$ %0.2f", cart.price))
                .font(.title3)
                .bold()

            HStack(spacing: UIConstants.spacingSmall) {
                Button {
                    viewModel.removeCart(id: cart.id)
                } label: {
                    Image(systemName: "trash")
                            .resizable()
                            .frame(width: UIConstants.iconSize, height: UIConstants.iconSize)
                            .foregroundStyle(ColorPalette.primary)
                }

                Spacer()

                Button {
                    //viewModel
                } label: {
                    Image(systemName: "plus")
                        .resizable()
                        .frame(width: UIConstants.iconSize, height: UIConstants.iconSize)
                        .foregroundStyle(ColorPalette.primary)
                }

                Text("\(cart.quantity)")
                    .multilineTextAlignment(.center)

                Button {
              //      productStore.decreaseQuantity(product: product)
                } label: {
                    Image(systemName: "minus")
                        .resizable()
                        .frame(width: UIConstants.iconSize, height: 3)
                        .foregroundStyle(ColorPalette.primary)
                }
            }
        }
        .padding()
        .clipShape(RoundedRectangle(cornerRadius: UIConstants.cornerRadiusCard))
        .overlay {
            RoundedRectangle(cornerRadius: UIConstants.cornerRadiusCard)
                .stroke(lineWidth: 2)
                .foregroundStyle(ColorPalette.background)
        }
    }
}
