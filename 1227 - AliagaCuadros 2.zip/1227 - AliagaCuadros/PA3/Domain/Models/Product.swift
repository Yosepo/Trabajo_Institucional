//
//  Shoe.swift
//  EasyShoes
//
//  Created by Alumno on 2/06/25.
//

struct Product: Identifiable {
    let id: Int
    let title: String
    let price: Double
    let image: String
}
