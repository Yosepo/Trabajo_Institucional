//
//  FavoriteProduct.swift
//  PA3
//
//  Created by Alumno on 23/06/25.
//

import Foundation

struct FavoriteProduct: Identifiable {
    let id: Int
    let title: String
    let image: String
    let price: Double
}
